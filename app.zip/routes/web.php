<?php

use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\DashboardController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\FrontendController;
use App\Http\Controllers\NotificationController;
use App\Http\Controllers\OrderController;
use App\Livewire\Checkout\CheckoutPage;
use App\Livewire\Checkout\MembershipCheckout;
use App\Livewire\Downloads\DownloadsIndex;
use Illuminate\Support\Facades\Artisan;
use App\Livewire\Library\ResourcesPage;
use App\Livewire\Library\ResourceDetailPage;
use App\Livewire\Membership\MembershipPlans;

Route::middleware('web')->group(function(){
    //Route::get('/', [FrontendController::class, 'index'])->name('index');


    Route::get('/index', App\Livewire\Library\LandingPage::class)->name('index');
    Route::get('/', App\Livewire\Library\LandingPage::class)->name('home');
    Route::get('/resources', App\Livewire\Library\ResourcesPage::class)->name('library.resources');
    Route::get('/group/{slug}', App\Livewire\Library\GroupPage::class)->name('library.group');
    Route::get('/category/{slug}', App\Livewire\Library\CategoryPage::class)->name('library.category');

    Route::get('resource/preview', [FrontendController::class, 'previewResource'])->name('resources.show');
    Route::get('/library', ResourcesPage::class)->name('library.resources');
    Route::get('/library/resource/{slug}', ResourceDetailPage::class)->name('library.resource.detail');
    Route::get('/membership/plans', MembershipPlans::class)->name('membership.plans');

    Route::middleware(['auth'])->group(function(){

        Route::any('logout', [DashboardController::class, 'logout'])->name('logout');    
        Route::get('dashboard', [DashboardController::class, 'index'])->name('dashboard');
        Route::get('/orders', [OrderController::class, 'index'])->name('orders.index');
        Route::get('/orders/{order}', [OrderController::class, 'show'])->name('orders.show');

        Route::get('/downloads', DownloadsIndex::class)->name('downloads.history');

        Route::get('/checkout/resume/{order}', [CheckoutController::class, 'resumeResourceCheckout'])->name('checkout.resume');    
        Route::get('/checkout/membership/resume/{order}', [CheckoutController::class, 'resumeMembershipCheckout'])->name('checkout.membership.resume');

        Route::get('/checkout/membership/success/{order}', [CheckoutController::class, 'membershipSuccess'])->name('checkout.membership.success');
        
        Route::get('/checkout/membership/{packageSlug}/{billingCycle}/{order?}', MembershipCheckout::class)->name('checkout.membership');   
        Route::get('/checkout/{order}', CheckoutPage::class) ->name('checkout');
        Route::get('/download/resource/{resource}', [App\Http\Controllers\ResourceDownloadController::class, 'download'])->name('library.resource.download');

        Route::get('/checkout/success/{order}', function ($order) {
            return view('livewire.checkout.success', compact('order'));
        })->name('checkout.success');

        Route::view('profile', 'profile')->name('profile');

        Route::middleware('admin')->group(function(){
            Route::view('notifications', 'notifications')->name('notifications');
            Route::view('sms', 'sms')->name('sms');
            Route::post('notify', [NotificationController::class, 'sendToAllUsers'])->name('notify');    
            Route::post('notifications', [NotificationController::class, 'sendToAllUsers'])->name('notifications.send');
            Route::get('/notifications/images', [NotificationController::class, 'listUploadedImages'])->name('notifications.images'); 
            Route::delete('/notifications/images/{filename}', [NotificationController::class, 'deleteImage'])->name('notifications.delete-image');
        });
       
    });

    require __DIR__ . '/auth.php';

    Route::get('artisan',function(){
        if(!empty($_GET['cmd'])){
            $cmd = $_GET['cmd'];
            Artisan::call($cmd);
            echo "Command '$cmd' executed successfully.\n<br>";
            echo nl2br(Artisan::output());
        } else {
            Artisan::call('config:clear');
            echo nl2br(Artisan::output());
            Artisan::call('view:clear');
            echo nl2br(Artisan::output());
            Artisan::call('cache:clear');
            echo nl2br(Artisan::output());
            Artisan::call('migrate', ['--force' => true]);
            echo nl2br(Artisan::output());
            exec('composer dump-autoload -d ' . base_path(), $output, $returnValue);
            //exec('ln -s ../public_html public',$output, $returnValue);        
            echo "Artisan commands executed successfully.\n<br>";
            echo json_encode($output);
            echo json_encode($returnValue);
        }
    });

    Route::get('/php-info', function() {
        phpinfo();
    });
});